/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef CANCELLER_MODEL_H
#define CANCELLER_MODEL_H
void 
canceller_new(void);

int 
canceller_new_sample(int x);

void
canceller_coeff_update (int e_);

#endif
/* [] END OF FILE */
