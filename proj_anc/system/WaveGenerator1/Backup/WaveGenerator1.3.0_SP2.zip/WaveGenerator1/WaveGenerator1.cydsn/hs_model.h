/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef HS_MODEL_H
#define HS_MODEL_H

int 
hs_model_new_sample(int x); 

void 
hs_model_new(int *coeffs);

#endif
/* [] END OF FILE */
