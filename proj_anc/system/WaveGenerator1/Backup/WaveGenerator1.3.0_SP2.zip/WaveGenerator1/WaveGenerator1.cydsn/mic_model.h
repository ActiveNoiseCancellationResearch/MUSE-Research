/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef MIC_MODEL_H
#define MIC_MODEL_H

int 
mic_model_new_sample(int x);    

void 
mic_model_new(int *coeffs);

#endif
/* [] END OF FILE */
