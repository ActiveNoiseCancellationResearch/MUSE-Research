/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
//using fixed point Q20.12 interpretation
#define FP_SHIFT (12)
#define FP_ROUND (1<<(FP_SHIFT-1))
#define WAVESIZE (20)
#define NUM_SAMPS_TO_CAPTURE (30000)
/* [] END OF FILE */