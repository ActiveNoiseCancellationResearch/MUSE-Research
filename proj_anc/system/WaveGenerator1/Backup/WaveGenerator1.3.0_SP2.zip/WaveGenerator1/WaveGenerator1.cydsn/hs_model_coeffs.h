/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef HS_MODEL_COEFFS_H
#define HS_MODEL_COEFFS_H

static int hs_model_coeffs[] =
{
    // Fill in from Julie's analysis of Shub's results from identifying the system response of the headphone speakers along with the microphone
};
    
#endif
/* [] END OF FILE */
