/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

int main()
{
#define NUM_TONES (1)           //number of tones to be generated
    int n;      // Discrete time index
    int freqs[] = { 200 };      // Array of tone frequencies, in Hz
    int ampls[] = { 16000 };    // Array of tone amplitudes, C1.0.15, roughly 0.5 for now
    int T       = 1000;          // Samping period, in microseconds
    int k;
    
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    VDAC8_Start();
    /* CyGlobalIntEnable; */ /* Uncomment this line to enable global interrupts. */
    for(n=0;;++n)
    {
        int value;
        int tones_sum=0;
        for (k = 0 ; k<NUM_TONES ; ++k)
        {
            
            value = n*T*freqs[k]/(1000000/(1<<15));
            value=value&0x7fff;
            value=(value*ampls[k])>>15;
            tones_sum+=value;                   //15 bit unsigned number
        }
        
        VDAC8_SetValue(tones_sum>>7);           //for it to fit into a 8bit range
        
        CyDelay(T/1000);
    }
}

/* [] END OF FILE */
